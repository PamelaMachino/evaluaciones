package evaluacionmodulo1;

public class Electrodomestico {
	
	//Atributos
	public double preciobase;
    public String color;
    public String consumoenergetico;
    public double peso;
    
    
    //Constantes
    protected final static double preciobase_def=100000;
	protected final static String color_def="blanco";
    protected final static String consumoenergetico_def="F";
    protected final static double peso_def=5;
    
    
    //Constructor por defecto
    public Electrodomestico(){
        this(preciobase_def, peso_def, consumoenergetico_def, color_def);
    }
    
    //Constructor atributos precio y peso. Consumoenergetico y color por defecto. 
    public Electrodomestico(double preciobase, double peso){
        this(preciobase, peso, consumoenergetico_def, color_def);
    }
    
    // Constructor con todos los atributos
    public Electrodomestico(double preciobase, double peso, String consumoenergetico_def, String color) {
		super();
		this.preciobase = preciobase;
		this.peso = peso;
		comprobarConsumoEnergetico(consumoenergetico_def);
		comprobarColor(color);
	}

    
    //M�todos get
	public double getpreciobase() {
        return preciobase;
    }
   
    public String getColor() {
        return color;
    }
   
    public String getconsumoenergetico() {
        return consumoenergetico;
    }
   
    public double getPeso() {
        return peso;
    }
    
    //Fin de m�todos get
    
    
    //Comprobar si la letra del consumo es correcta (desde A hasta F)
    public void comprobarConsumoEnergetico(String consumoenergetico){
        
        if(consumoenergetico.equalsIgnoreCase("A") || consumoenergetico.equalsIgnoreCase("B") 
        	|| consumoenergetico.equalsIgnoreCase("C") || consumoenergetico.equalsIgnoreCase("D") 
        	|| consumoenergetico.equalsIgnoreCase("E") || consumoenergetico.equalsIgnoreCase("F")){
            this.consumoenergetico=consumoenergetico;
        }else{
            this.consumoenergetico=consumoenergetico_def;
        }       
    }
    
    public void comprobarColor(String color){
    	   
        String coloresdisp[]={"blanco", "negro", "rojo", "azul", "gris"};
        boolean compcolor=false;
  
        for(int i=0;i<coloresdisp.length && !compcolor;i++){
              
            if(coloresdisp[i].equalsIgnoreCase(color)){
                compcolor=true;
                this.color=color;
            }   else {
            	this.color=color_def;
            	}
        }
    }

    public double precioFinal(){
        double aumento=0;
        
        switch(consumoenergetico){
            case "A":
                aumento+=85000;
                break;
            case "a":
                aumento+=85000;
                break;
            case "B":
                aumento+=70000;
                break;
            case "b":
                aumento+=70000;
                break;
            case "C":
                aumento+=50000;
                break;
            case "c":
                aumento+=50000;
                break;
            case "D":
                aumento+=40000;
                break;
            case "d":
                aumento+=40000;
                break;
            case "E":
                aumento+=25000;
                break;
            case "e":
                aumento+=25000;
                break;
            case "F":
                aumento+=8500;
                break;
            case "f":
                aumento+=8500;
                break;
        }
   
        if(peso>=0 && peso<=19){
            aumento+=8500;
        }else if(peso>=20 && peso<=49){
            aumento+=40000;
        }else if(peso>=50 && peso<=79){
            aumento+=70000;
        }else if(peso>=80){
            aumento+=85000;
        }
        return preciobase+aumento;
    }
   
   
   
   
  
  
}

	
	    