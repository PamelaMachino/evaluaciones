package evaluacionmodulo1;

public class Television extends Electrodomestico{
	
	 int resolucion;
	 boolean sintonizadorTDT;
	  
	 final static int resolucion_def=20;
	 final static boolean sintonizadorTDT_def=false;
	 
	
	 //Constructor por defecto
	 public Television(){
	     this(preciobase_def, peso_def, consumoenergetico_def, color_def, resolucion_def, sintonizadorTDT_def);
	 }
   
	 //Constructor precio y peso. Consumo, color, resolucion y sintonizador por defecto
	 public Television(double preciobase, double peso){
	        this(preciobase, peso, consumoenergetico_def, color_def, resolucion_def, sintonizadorTDT_def);
	    }
	 
	 //Constructor con resolucion, sintonizador y atributos heredados
	 public Television(double preciobase, double peso, String consumoenergetico, String color, int resolucion, boolean sintonizadorTDT){
	        super(preciobase, peso, consumoenergetico, color);
	        this.resolucion=resolucion;
	        this.sintonizadorTDT=sintonizadorTDT;
	    }
   
	 
	 //M�todos get resolucion y sintonizador
		public int getResolucion() {
			return resolucion;
		}

		public boolean isSintonizadorTDT() {
			return sintonizadorTDT;
		}

		
    public double precioFinal(){
        double aumento=super.precioFinal();
  
        if (resolucion>40){
            aumento+=preciobase*0.3;
        }
        if (sintonizadorTDT=true){
            aumento+=45000;
        }  
        return aumento;
    }


    
  

  
 
  
  
   
}


	