package evaluacionmodulo1;

public class Lavadora extends Electrodomestico{
	  
	int carga;
    final static int carga_def=5;
  
    //Constructor por defecto
    public Lavadora(){
        this(preciobase_def, peso_def, consumoenergetico_def, color_def, carga_def);
    }
    
    //Constructor precio y peso. Consumo, color y carga por defecto
    
    public Lavadora(double preciobase, double peso){
        this(preciobase, peso, consumoenergetico_def, color_def, carga_def);
    }
    
    //Constructor carga y atributos heredados
    public Lavadora(double preciobase, double peso, String consumoenergeticoDef, String color, int carga){
        super(preciobase, peso, consumoenergeticoDef, color);
        this.carga=carga;
    }
    
    //M�todo get de carga
    public int getCarga() {
        return carga;
    }
  
    
    public double precioFinal(){
        double aumento=super.precioFinal();

        if (carga>30){
            aumento+=40000;
        }
        return aumento;
    }   
}





















	