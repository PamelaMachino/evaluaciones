package evaluacionmodulo1;

import javax.swing.JOptionPane;

public class Ejecutable {

	public static void main(String[] args) {
		   
        
        Electrodomestico arregloelectro[]=new Electrodomestico[10];
   
        
        arregloelectro[0]=new Electrodomestico(119000, 20, "c", "negro");
        arregloelectro[1]=new Lavadora(360000, 80, "d","blanco", 40);
        arregloelectro[2]=new Television(450000, 20);
        arregloelectro[3]=new Television(550000, 15, "k", "celeste", 30, false);
        arregloelectro[4]=new Electrodomestico(240000, 10);
        arregloelectro[5]=new Lavadora(470000, 76);
        arregloelectro[6]=new Lavadora(510000, 60, "b", "blanco", 80);
        arregloelectro[7]=new Electrodomestico(40000, 3, "b", "rojo");
        arregloelectro[8]=new Electrodomestico(120000, 10, "a", "gris");
        arregloelectro[9]=new Television(150000, 15, "c", "negro", 45, true);
        
   
        double precioelectrodomesticos=0;
        double preciotelevisiones=0;
        double preciolavadoras=0;
   
        for(int i=0;i<arregloelectro.length;i++){
           
            if(arregloelectro[i] instanceof Electrodomestico){
                precioelectrodomesticos+=arregloelectro[i].precioFinal();
            }
            if(arregloelectro[i] instanceof Television){
                preciotelevisiones+=arregloelectro[i].precioFinal();
            }
            if(arregloelectro[i] instanceof Lavadora){
                preciolavadoras+=arregloelectro[i].precioFinal();
            }
            
        }
   
        JOptionPane.showMessageDialog(null,""
        +"\n Suma de precios de todos los electrodom�sticos: "+precioelectrodomesticos 
        +"\n Suma de precios de todas las televisiones: "+preciotelevisiones
        +"\n Suma de precios de todas las lavadoras: "+preciolavadoras);
     
   
    }
   
}

		 
	    